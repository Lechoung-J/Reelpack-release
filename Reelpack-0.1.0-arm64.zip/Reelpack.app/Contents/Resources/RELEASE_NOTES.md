# Reelpack 0.1.0 — preview

**Status:** early public preview.

## Platform

- Apple Silicon / **arm64** only. This archive contains arm64 executables; Intel / x86_64 is not built or validated.
- **Minimum deployment target: macOS 14.** macOS 14 hardware validation has not yet been performed.
- Native **Python 3.12** and **FFmpeg / ffprobe** are required for the runtime. Five Python environments remain separate.

## Install

Keep `install.sh`, the App ZIP and its matching `release-manifest.json` together. Save and inspect the script before running it.

```sh
bash install.sh --archive Reelpack-0.1.0-arm64.zip \
  --manifest release-manifest.json --no-launch
```

Default destinations:

- App: `~/Applications/Reelpack.app`.
- Environments: `~/Library/Application Support/Reelpack/runtime/arm64/`.
- Skill: provided in `Reelpack.app/Contents/Resources/SKILL.md`, with a runtime copy and Agent integration instructions.
- Command: the installer prints the exact `reelpack` launcher location and PATH guidance. The native executable remains `reelpack-cli`.

The installer verifies the archive hash and contents, creates or checks native environments, and checks FFmpeg. Existing App/environment files are preserved unless an explicit replacement or repair option is supplied. Use `bash install.sh --help` for those options. It does not use sudo or silently install system FFmpeg.

## Local file engine and Agent workflow

```sh
reelpack "/path/to/video.mp4" --output-dir ~/Reelpack
reelpack query --output-dir ~/Reelpack "keyword"
```

Reelpack takes a **local video file** and produces an asset package. It does not download media, scrape webpages, resolve social/platform links, or include a video-channel parser. URL input is rejected with guidance to have the user or their Agent obtain a local file first.

The supplied [SKILL.md](SKILL.md) explains reference-film analysis, advertisement breakdown, transcription and reading the package. The installer provides instructions for Claude Code, Codex and Cursor and registers the skill only where a supported Agent directory is present and existing custom content can be preserved. It does not create an MCP server or add browsing/downloading capabilities.

`reelpack query` performs a literal read-only lookup over existing transcript, OCR and summary text. It does not run analysis, a model or a network request; detailed shot/time/evidence queries remain available through `Core/asset_cli.py`.

## Archive contents

- Reelpack Swift App and `reelpack-cli`.
- Python asset pipeline and pinned environment requirements.
- Native macOS Vision OCR helper and v3 icon.
- README files, Skill, these notes, license and installer.
- A ZIP without `__MACOSX/`, AppleDouble files or Finder metadata; matching SHA-256 file and external installation manifest.

Python environments, model weights, FFmpeg and user videos are not embedded in the App.

## Known limitations

- **Not notarized.** This build uses local ad-hoc signing, without Developer ID distribution or Apple notarization. **Downloaded copies may be blocked by macOS Gatekeeper; clean-download Gatekeeper acceptance has not been validated.**
- **Models are separate.** large-v3 must be explicitly prepared; when not ready, the tool states the approximate ~3.1 GB cost and does not silently download. Optional PANNs checkpoints and its class-label file are BYO and have independent licenses; missing semantic weights remain `not_run` while successful physical audio analysis stays `complete`.
- **Local files only.** Supported pipeline input formats are MP4, MOV and MKV. Obtaining a video from a link belongs to the user or their Agent.
- OCR uses original-media sampling up to 1920px wide; recognition errors and missing fast-changing subtitles remain possible.
- OpenCV/PyAV duplicate AVFoundation class warnings remain observable. Existing tests and real-video runs completed without a crash, but the warning is not resolved.

## License

[FSL-1.1-MIT](LICENSE). Dependencies, system tools and model weights retain their own licenses.
