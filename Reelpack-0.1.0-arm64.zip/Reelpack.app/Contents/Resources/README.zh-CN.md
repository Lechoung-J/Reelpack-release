# Reelpack

将本地视频整理为可查询的资产包：带时间戳的转录、镜头切点、证据帧、分镜板、画面文字与音频描述子。要求 macOS 14 或以上；Intel 和 Apple Silicon 的 Python 环境与原生工具需在各自机器创建。

## 安装

安装包仅包含 Swift App/CLI、Python 源码和 macOS Vision OCR 工具。安装脚本会在用户目录建立五套原生 Python 环境，检查 FFmpeg/ffprobe。模型和原视频不放入 App。

已下载并核验的本地安装包可以这样安装：

```sh
bash install.sh --archive Reelpack-0.1.0-arm64.zip \
  --sha256 Reelpack-0.1.0-arm64.zip.sha256 --no-launch
```

默认 App 位于 `~/Applications/Reelpack.app`，运行环境位于 `~/Library/Application Support/Reelpack/runtime/arm64`。Intel 使用 `x86_64` 目录。执行 `bash install.sh --help` 查看当前支持的参数。

首次使用前，请准备原生 Python 3.12（也可使用已有 uv 管理的解释器）和 FFmpeg。脚本不使用 sudo，不代装需要单独许可的模型。PANNs 权重缺失时，`music.tagging` 为 `not_run`，已完成的 BPM、拍点与响度分析仍保持完整状态。

Release、代理和镜像需要真实托管文件。私有仓库通过 GitHub CLI 的登录权限直接下载；不会将令牌发送给第三方代理。jsDelivr 用于小型脚本或清单，不能假定它可以代理 GitHub Release 二进制。Gitee 未配置时跳过该来源。

## 本地构建

```sh
make -f Build/Makefile ARCH=arm64 VERSION=0.1.0 bundle
```

会生成 `Reelpack.app`、ZIP、SHA-256 文件和体积/构成清单。脚本保留既有产物；重新构建时可指定新的 `OUTPUT_DIR`。本阶段为本机 ad-hoc 签名，没有公证。

## 处理与查询

App 支持拖入视频、选择文件或输入本地路径。主管线也可直接运行：

```sh
.venv/bin/python Core/core.py --input "/path/to/video.mp4" \
  --output-dir "/path/to/output" --library-root "/path/to/library" \
  --ocr-backend macos --language auto
```

OCR 直接从原片采样，默认宽度上限 1920 像素，不放大低分辨率输入。`--ocr-max-width 0` 保留源分辨率，采样间隔仍为 5 秒；对快速变化的字幕，采样密度和识别准确率需分别评估。

资产包以 JSON 为结构化主结果，包含 Markdown、证据帧和按需生成的图片板。未知、失败和未运行的能力保留明确状态，不用摘要替代原文。

## 许可

项目采用 [LICENSE](LICENSE) 中的 FSL-1.1-MIT。依赖库、系统工具和可选权重各自保留其许可。
