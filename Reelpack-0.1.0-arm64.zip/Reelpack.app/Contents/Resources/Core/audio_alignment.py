def align_cuts_to_beats(cuts, beats, tolerance=.15):
    offsets=[]
    for cut in cuts:
        if beats:
            delta=min((float(cut)-float(beat) for beat in beats),key=abs)
            offsets.append(delta)
    aligned=sum(abs(x)<=tolerance for x in offsets)
    return {'cut_count':len(cuts),'beat_count':len(beats),'tolerance_seconds':tolerance,'aligned_cut_count':aligned,'aligned_ratio':aligned/len(cuts) if cuts else None,'mean_signed_offset_seconds':sum(offsets)/len(offsets) if offsets else None,'mean_absolute_offset_seconds':sum(map(abs,offsets))/len(offsets) if offsets else None,'offsets_seconds':offsets}
