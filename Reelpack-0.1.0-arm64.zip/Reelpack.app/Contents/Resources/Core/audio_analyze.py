#!/usr/bin/env python3
"""Isolated permissive-stack audio descriptors. Run with .venv-audio Python."""
from __future__ import annotations
import argparse, json, subprocess, sys, tempfile
from music_timbre import analyze_timbre
from pathlib import Path


def extract_audio(path: str, sr: int = 22050):
    import numpy as np
    import soundfile as sf
    with tempfile.NamedTemporaryFile(suffix='.wav') as tmp:
        subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-i',path,'-map','0:a:0','-vn','-ac','1','-ar',str(sr),tmp.name], check=True, timeout=900)
        y, rate = sf.read(tmp.name, dtype='float32')
    if y.ndim > 1: y = y.mean(axis=1)
    return np.asarray(y), rate


def analyze_array(y, sr: int, *, hop_seconds=.5):
    import numpy as np
    import librosa
    import pyloudnorm as pyln
    y = np.asarray(y, dtype=np.float32)
    if y.size == 0: raise ValueError('empty audio')
    hop = max(1, int(sr * hop_seconds)); frame = max(1, int(sr))
    rms = librosa.feature.rms(y=y, frame_length=frame, hop_length=hop, center=True)[0]
    rms_times = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=hop).tolist()
    onset_frames = librosa.onset.onset_detect(y=y, sr=sr, units='frames')
    onset_times = librosa.frames_to_time(onset_frames, sr=sr).tolist()
    tempo, beat_frames = librosa.beat.beat_track(y=y, sr=sr, units='frames')
    tempo_val = float(np.asarray(tempo).reshape(-1)[0])
    beats = librosa.frames_to_time(beat_frames, sr=sr).tolist()
    try:
        loudness = float(pyln.Meter(sr).integrated_loudness(y))
        loudness_status = 'complete'
    except Exception as exc:
        loudness, loudness_status = None, 'failed'
        loudness_error = str(exc)
    return {'status':'partial' if loudness_status != 'complete' else 'complete', 'backend':'librosa+soundfile+pyloudnorm', 'model':None, 'params':{'sample_rate':sr,'channels':1,'rms_segment_seconds':hop_seconds,'beat_tracking':'librosa.beat.beat_track','onset':'librosa.onset.onset_detect','loudness':'ITU-R BS.1770 via pyloudnorm'}, 'tempo_bpm':tempo_val,'beat_times_seconds':beats,'beat_count':len(beats),'onset_times_seconds':onset_times,'energy':{'type':'rms','segment_seconds':hop_seconds,'times_seconds':rms_times,'values':rms.astype(float).tolist()},'loudness':{'status':loudness_status,'integrated_lufs':loudness, **({'error':loudness_error} if loudness_status=='failed' else {})}, 'genre':{'status':'not_run'}, 'mood':{'status':'not_run'}, 'timbre': analyze_timbre(y, sr)}


def analyze(path: str):
    y, sr = extract_audio(path)
    return analyze_array(y, sr)

if __name__ == '__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('input'); a=ap.parse_args()
    try: print(json.dumps(analyze(a.input), ensure_ascii=False))
    except Exception as e:
        print(json.dumps({'status':'failed','backend':'librosa+soundfile+pyloudnorm','model':None,'params':{},'error':f'{type(e).__name__}: {e}','genre':{'status':'not_run'},'mood':{'status':'not_run'}},ensure_ascii=False)); sys.exit(0)
