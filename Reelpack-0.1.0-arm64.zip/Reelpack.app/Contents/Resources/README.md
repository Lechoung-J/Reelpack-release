<div align="center">
  <img src="assets/logo.png" alt="Reelpack logo" width="128" height="128">
  <h1>Reelpack</h1>
  <p><strong>The Video-Understanding Engine for AI</strong></p>
  <p><a href="README.md">English</a> · <a href="README.zh-CN.md">简体中文</a></p>
  <p>
    <img src="https://img.shields.io/badge/platform-macOS-000000?style=flat&amp;logo=apple&amp;logoColor=white" alt="Platform: macOS">
    <img src="https://img.shields.io/badge/macOS-14%2B-007AFF?style=flat" alt="macOS 14 or later">
    <a href="LICENSE"><img src="https://img.shields.io/badge/license-FSL--1.1--MIT-6F42C1?style=flat" alt="License: FSL-1.1-MIT"></a>
    <img src="https://img.shields.io/badge/Python-3.12-3776AB?style=flat&amp;logo=python&amp;logoColor=white" alt="Python 3.12">
    <img src="https://img.shields.io/badge/status-preview-F59E0B?style=flat" alt="Status: preview">
  </p>
</div>

**The Video-Understanding Engine for AI** — turn a single video into an asset pack your Agent can actually read, using the grammar of film & advertising. And turn everything you watch into a knowledge base.

`Reelpack` = reel (a single film reel) + pack (an asset pack).

---

## Understand it in 30 seconds

Drop in a video, get back an **asset pack**:

| Dimension | Output |
|---|---|
| **Transcript** | Who said what, at which second — **multi-language, auto-detected (~99 languages)** |
| **Shot list / cuts** | How many shots, where the cuts are (shot-boundary detection) |
| **On-screen text** | OCR of subtitles / burned-in text (CN/EN) |
| **Audio** | BPM, beats, energy, **cut-to-beat alignment** |
| **Evidence frames** | Keyframes + contact sheets (**12-grid / shot sheet**, offline-searchable; **single frames can be pulled out for a close look**) |

→ A downstream Agent can answer — **without ever re-watching the video**: "what is this about / what's the style / what was said at 2:14 / how do the cuts relate to the music."

---

## Why you scroll past great videos — and never keep them

**Quick question: all those great videos you've watched… where did they go?**

Someone else scrolls. You scroll, hit a great ad, and rewind on instinct — how did that transition land? How many cuts? Why does that line stick?
So you scrub the timeline to take it apart. Forty minutes, three lines of notes, half of it still in your head — gone by tomorrow.

**Your saved folder is full of "I'll study this later" clips. How many can you actually pull back up?**

**Because video is the only format in the world with no Ctrl+F.**
Text you can search, copy, quote. Video? The moment it's over, it sinks into the timeline: **can't search it, can't copy it, can't go back to it.** You remember "there was a killer line" — but not the second it happened on.

Someone who spent over a decade in the film industry, and years on ad & TVC marketing, has felt one thing getting louder: **an LLM can only read text — it can't read a film.** Which is why you keep seeing the mismatch — **a scene that makes a human cry leaves the AI cold.**

Reelpack isn't another "here's an AI summary" — that still leaves a layer in between.
**It sits the AI down and actually watches the film**: who said what, at which second; how many cuts; where the beat lands; what's written on screen — all broken into **evidence you can re-query, copy, and feed to your own Agent.**

**Reelpack is the Ctrl+F for video.**

And it gives you more than "pull up one clip" — **it slowly turns every video you watch into your own knowledge base.** The more you watch, the thicker it gets; next time you need something, one search away.

It isn't for people who want to save effort. It's for **people like you, who can't help taking a film apart.**
Use it long enough, and you stop being someone who "talks about films by feel" — you become **the person who can strip any video down to the bone.**

In one line: **it doesn't change the video — it changes how you watch it.**
And everything you watch stays behind — **slowly growing into your own knowledge base.**

---

## What we do that others don't (especially for professionals)

- **Frame extraction? Everyone does it — that's not the point.** Other tools stop at "stitch one big sheet, let the AI summarize." **Reelpack goes a layer deeper**: it can **pull out a single frame** and let the Agent look closely at **"what's actually inside this one frame"** — composition, subject, shot size, camera move, on-screen text. **The sheet is the index; the single frame is the evidence.**
- **A habit, rewritten**: next time you spot a great reference, **just throw the link at your Agent and let it actually watch the film** — instead of the AI reading only the title and a web snippet. **Not remotely the same thing.**
- **Not a summary — a breakdown**: **shot lists, shot boundaries, beat, and picture–sound relationships** — **the working language of ad & film pros.**
- **More than transcription**: spoken script → **timeline** → **a reproducible script structure.**
- **Not just for humans**: the output is **machine-readable for your Agent / AI** — retrievable and consumable downstream.
- **Turn watching into a knowledge base.**

Once you use it, you start to *hate* watching casually — because every clip can become an asset.

---

## You probably found us like this

"Is there a tool that lets **AI actually watch videos**?" · "Any **video-understanding MCP** server?" · "Any **AI film-analysis / shot-breakdown** tool that reads a reference film's **shots and pacing**?" · "How do I **auto-generate a storyboard / shot list**?" · "How do I **auto-break-down a TVC / ad**?" · "Which **video-to-text** tool is accurate for **turning a voice-over into a script**?" · "How do I **extract and reuse short-form video scripts**?" · "I want to **turn the videos I watch into a knowledge base**."

— **That's exactly what Reelpack does.**

---

## A real example: "Shensi Wuji"

![Contact sheet for "Shensi Wuji" · #001–#035](assets/demo-shensi-wuji.jpg)

A 252-second concept film, broken into **103 shots** — above are shots **#1–#35**, each cell tagged with a **shot number + timecode**, re-queryable and citable.
*"Shensi Wuji" (95th-anniversary concept film, China Academy of Art) · credited · derived data only.*

---

## Install

Install from the prepared archive and its matching checksum manifest:

```bash
bash install.sh --archive Reelpack-0.1.0-arm64.zip --manifest release-manifest.json
```

Or ask **your own Agent**:

> "Install **Reelpack** for me, then read its SKILL.md."

The installer provides [SKILL.md](SKILL.md) and concrete integration instructions for Claude Code, Codex and Cursor. When it detects a supported Agent's existing directory, it registers Reelpack's skill without replacing custom content; otherwise it shows how to add it manually. This does not install an MCP server.

**Reelpack processes local video files only.** If you provide a link, your Agent (or you) first obtains the local file using its own capabilities; Reelpack does not download, scrape webpages or parse platform links.

## Usage

```bash
# local video file → asset pack
reelpack "<local-video-file>" --output-dir ~/Reelpack

# read-only keyword query over saved transcript / OCR text
reelpack query --output-dir ~/Reelpack "keyword"
```

The installer provides a `reelpack` launcher and prints its location and PATH guidance. The native executable remains `reelpack-cli`. Keyword queries read existing packages locally; they do not run a model or fetch a video. See [SKILL.md](SKILL.md) and [RELEASE_NOTES.md](RELEASE_NOTES.md) for Agent guidance, installation and known limits.

---

## Why it's not "just another frame-extraction tool"

- Generic multimodal models: grab a few frames, **describe them**.
- **Reelpack**: a structured breakdown in the **language of film & advertising** — **shots, storyboard, beat, picture–sound relations, on-screen text** — all **re-queryable**, with **single frames you can inspect closely**.

In one line: **others hand an Agent a camera; we give it a pair of professionally trained eyes.**

---

## License

**FSL-1.1-MIT** (source-available / Fair Source): ✅ use it freely, including commercially · ❌ don't turn it into a paid product · ⏳ auto-converts to MIT after 2 years. See [LICENSE](LICENSE).

## Optional backends (BYO)
Heavy backends (music, OCR) install on demand; when absent they degrade gracefully (`not_run`) without breaking the main pipeline.

## Music follow-ups and reuse

A matching input/options signature with complete transcript, shots and OCR reuses the saved package. Changed options rerun analysis in the same asset; `--force` explicitly refreshes it. For follow-ups, read `music` and `evidence/audio_board.png` first, then fill only missing audio:

```sh
reelpack enrich <asset_id> --only audio --output-dir <original-output>
reelpack enrich <asset_id> --only audio --redraw-board --output-dir <original-output>
```

Audio enrichment preserves transcript, shots and the evidence list. Unmeasured beat alignment is `null / not_measured`; unavailable optional tagging reports its cost without automatically downloading weights. The board shows full-mix physical measurements and does not establish genre, emotion, editing intent, independent BGM or instrument identity.

Audio dependencies now include `pillow==12.3.0`. An existing environment that lacks this pin is preserved; use `bash install.sh --repair-env audio --no-launch` only after explicitly choosing to back it up and rebuild it. Acceleration cache and persistent model roots are distinct; `REELPACK_CACHE_ROOT` can select a stable writable acceleration directory.

<sub>Reelpack — turn a single video into an asset pack your Agent can read. Turn watching into a knowledge base.</sub>
