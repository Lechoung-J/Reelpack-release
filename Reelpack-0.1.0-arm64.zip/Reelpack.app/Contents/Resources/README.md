# ReadWechat Video / Reelpack

Turn a local video into a persistent asset package for downstream agents: timed transcripts, shot boundaries, evidence frames, contact sheets, OCR text and audio descriptors.

This source branch accepts local files. It supports native development on Intel and Apple Silicon Macs with macOS 14 or later. Python environments and native binaries must be created on each machine.

## Capabilities

- Multilingual faster-whisper large-v3 transcription with VAD and bounded timestamps.
- TransNetV2 shot detection with an explicitly reported OpenCV fallback.
- Native macOS Vision OCR from original media, capped at 1920 pixels wide without upscaling; optional independent OCR backends.
- Audio BPM, beats, onsets, loudness, spectral descriptors and cut-to-beat alignment.
- Structured asset packages with JSON, Markdown, evidence frames and contact sheets.
- Optional PANNs music classification with user-provided model weights. Physical audio analysis retains its own status/backend; `music.tagging` reports missing or failed semantic models independently.
- Optional summary and correction backends; both are disabled by default.

## Apple Silicon environment setup

Use native Python 3.12.4 and FFmpeg/ffprobe. Create the five environments separately; their NumPy requirements differ. The checked-in environment snapshots record the tested Apple Silicon dependency versions.

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r Core/requirements-arm64.txt

python3.12 -m venv .venv-audio
.venv-audio/bin/python -m pip install -r Core/requirements-audio.txt

python3.12 -m venv .venv-transnet
.venv-transnet/bin/python -m pip install -r Core/requirements-transnet.txt -c Core/constraints-transnet.txt

python3.12 -m venv .venv-ocr
.venv-ocr/bin/python -m pip install -r Core/requirements-ocr.txt

python3.12 -m venv .venv-music
.venv-music/bin/python -m pip install -r Core/requirements-music.txt

ARCH=arm64 sh Tools/macos_ocr/build.sh
```

Intel builds use native x86_64 Python and `ARCH=x86_64` for the OCR helper. Check native wheel availability before using the Apple Silicon snapshots on Intel.

PANNs weights and its AudioSet class-label table are user-provided assets. The application checks their presence before loading the optional backend and does not download missing weights. Model licenses are separate from this project's source license.

## Process and query a video

Pass both the output directory and library root explicitly. The first contains the standalone Markdown output; the second contains the persistent asset package and archived media.

```sh
.venv/bin/python Core/core.py \
  --input "/path/to/video.mp4" \
  --output-dir "/path/to/output" \
  --library-root "/path/to/library" \
  --ocr-backend macos --language auto

.venv/bin/python Core/asset_cli.py --library-root "/path/to/library" list
.venv/bin/python Core/asset_cli.py --library-root "/path/to/library" show ASSET_ID
.venv/bin/python Core/asset_cli.py --library-root "/path/to/library" validate ASSET_ID
```

The asset library stores `packages/`, `media/` and `cache/` separately. Package paths are relative; original media is archived locally. Optional capabilities report `not_run` or `failed` rather than manufacturing results. Native OCR must run in an environment that allows Vision/IOSurface access.

## Swift application and installer

```sh
make -f Build/Makefile ARCH=arm64 VERSION=0.1.0 bundle
bash install.sh --archive Reelpack-0.1.0-arm64.zip \
  --sha256 Reelpack-0.1.0-arm64.zip.sha256 --no-launch
```

The builder produces `Reelpack.app`, an archive, SHA-256 checksum and a component-size manifest. The app contains the Swift App/CLI, Python sources and native OCR helper. Python environments, FFmpeg and model weights are installed or prepared separately in the user's account. Existing build artifacts are preserved.

The installer validates architecture, macOS version, archive checksum and five separate Python environments. The default app location is `~/Applications/Reelpack.app`; runtime environments are stored under `~/Library/Application Support/Reelpack/runtime/<architecture>`. The app and CLI locate the same runtime independently of the current directory or Finder's PATH. `Reelpack.app/Contents/MacOS/Reelpack --runtime-check` reports the actual installed dependencies.

GitHub Release downloads require a published artifact; private repositories use authenticated GitHub CLI access without forwarding credentials to proxies. Public proxy, jsDelivr manifest/script and Gitee sources require actual configured mirrors. This source does not claim that a mirror is already hosted. Run `bash install.sh --help` for available download and offline-install options.

Builds use local ad-hoc signing by default. Notarization and Developer ID distribution are separate release steps. See [README.zh-CN.md](README.zh-CN.md) for Chinese instructions.

## License

See [LICENSE](LICENSE) for the project's Functional Source License, Version 1.1, MIT Future License. Dependencies, system tools and optional model weights retain their own licenses.
