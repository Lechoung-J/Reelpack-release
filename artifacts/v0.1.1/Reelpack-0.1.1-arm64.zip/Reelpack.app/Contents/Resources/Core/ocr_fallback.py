"""Native-first, error-only OCR fallback; no model loading or downloads here."""
import json
from pathlib import Path
import subprocess
import tempfile

STRATEGY_VERSION = 'native-error-fallback-v1'
NATIVE_TIMEOUT_SECONDS = 300
FALLBACK_TIMEOUT_SECONDS = 120
NATIVE_MODEL = 'Apple Vision'


def _frame(timestamp, refs, status, reason=None):
    return dict(timestamp=timestamp, status=status,
                evidence_ids=list((refs or {}).get(timestamp, [])), reason=reason)


def _item(timestamp, refs, text, backend, model, reason=None, original=None):
    item = dict(original or {})
    item.update(timestamp=timestamp, start=timestamp, end=timestamp, text=text,
                evidence_ids=list((refs or {}).get(timestamp, [])), status='complete',
                backend=backend, model=model, source=backend,
                fallback_from='macos' if backend == 'rapidocr' else None, reason=reason)
    return item


def _status(frames):
    statuses = [frame['status'] for frame in frames]
    if all(status == 'complete' for status in statuses):
        return 'complete'
    if 'complete' in statuses:
        return 'partial'
    return 'not_run' if all(status == 'not_run' for status in statuses) else 'failed'


def _native(frames, refs, ocr_bin, runner):
    attempt = dict(backend='macos', model=NATIVE_MODEL,
                   params={'timeout_seconds': NATIVE_TIMEOUT_SECONDS},
                   status='complete', frames=[], errors=[], reason=None)
    items = []
    stderr = ''
    try:
        with tempfile.TemporaryDirectory(prefix='reelpack-native-ocr-') as directory:
            paths = []
            for index, (_, image) in enumerate(frames):
                path = Path(directory) / f'frame_{index:03d}.jpg'
                path.write_bytes(image)
                paths.append(str(path))
            result = (runner or subprocess.run)(
                [str(ocr_bin), '--json', *paths], capture_output=True,
                text=True, timeout=NATIVE_TIMEOUT_SECONDS)
            stderr = result.stderr.strip()
            if result.returncode:
                raise RuntimeError(f'macOS Vision OCR exit {result.returncode}: {result.stderr.strip()}')
            start = result.stdout.find('{')
            payload = json.loads(result.stdout[start:] if start >= 0 else result.stdout)
            rows = payload.get('frames') if isinstance(payload, dict) else None
            if not isinstance(rows, list) or len(rows) != len(frames):
                raise ValueError('macOS Vision OCR response frame count mismatch')
            if 'count' in payload and payload['count'] != len(frames):
                raise ValueError('macOS Vision OCR response count mismatch')
            # Validate the entire mapping before retaining any observations.
            for path, row in zip(paths, rows):
                if not isinstance(row, dict) or row.get('file') != path:
                    raise ValueError('macOS Vision OCR response frame path mismatch')
                if not row.get('error') and not isinstance(row.get('text'), str):
                    raise ValueError('macOS Vision OCR response text must be a string')
            for (timestamp, _), row in zip(frames, rows):
                reason = str(row['error']) if row.get('error') else None
                attempt['frames'].append(_frame(timestamp, refs, 'failed' if reason else 'complete', reason))
                if reason:
                    attempt['errors'].append(dict(backend='macos', timestamp=timestamp, reason=reason))
                else:
                    items.append(_item(timestamp, refs, row['text'], 'macos', NATIVE_MODEL))
    except Exception as exc:
        reason = f'{type(exc).__name__}: {exc}'
        detail = getattr(exc, 'stderr', None) or stderr
        if detail and str(detail) not in reason:
            reason += f'; stderr: {detail}'
        status = 'not_run' if isinstance(exc, FileNotFoundError) else 'failed'
        attempt['frames'] = [_frame(ts, refs, status, reason) for ts, _ in frames]
        attempt['errors'] = [dict(backend='macos', reason=reason)]
        items = []
    attempt['status'] = _status(attempt['frames'])
    attempt['reason'] = '; '.join(error['reason'] for error in attempt['errors']) or None
    return items, attempt


def _rapid(frames, refs, rapid, native_reasons):
    try:
        if rapid is None:
            from optional_backends import recognize_frames
            def bounded_runner(command, **kwargs):
                kwargs['timeout'] = FALLBACK_TIMEOUT_SECONDS
                kwargs['env'] = {**kwargs.get('env', {}), 'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1'}
                return subprocess.run(command, **kwargs)
            def rapid(selected, references):
                return recognize_frames(selected, references, runner=bounded_runner)
        response = rapid(frames, refs)
        if not isinstance(response, dict) or response.get('status') not in ('complete', 'partial', 'failed', 'not_run'):
            raise ValueError('invalid RapidOCR response status')
        rows, errors = response.get('items', []), response.get('errors', [])
        if not isinstance(rows, list) or not isinstance(errors, list):
            raise ValueError('invalid RapidOCR response items/errors')
        timestamps = {ts for ts, _ in frames}
        for row in rows:
            if not isinstance(row, dict) or row.get('timestamp') not in timestamps or not isinstance(row.get('text'), str):
                raise ValueError('invalid RapidOCR response frame/text')
    except Exception as exc:
        response = dict(status='failed', reason=f'{type(exc).__name__}: {exc}', items=[], errors=[])
        rows, errors = [], []

    model = response.get('model') or 'RapidOCR'
    reason = response.get('reason')
    normalized_errors = [dict(error, backend='rapidocr') if isinstance(error, dict)
                         else dict(backend='rapidocr', reason=str(error)) for error in errors]
    if response['status'] != 'complete' and not reason:
        reason = '; '.join(str(error.get('reason', error)) for error in normalized_errors) or f"RapidOCR {response['status']}"
    if reason and not normalized_errors:
        normalized_errors.append(dict(backend='rapidocr', reason=reason))
    errors_by_ts = {error['timestamp']: str(error.get('reason') or reason or 'RapidOCR frame failed')
                    for error in normalized_errors if error.get('timestamp') in {ts for ts, _ in frames}}
    # The existing worker reports each failed timestamp, including when other
    # frames completed with no text. Unmapped partial errors cannot prove that.
    mapped_partial = response['status'] == 'partial' and normalized_errors and all(
        error.get('timestamp') in errors_by_ts for error in normalized_errors)
    attempt = dict(backend='rapidocr', model=model, params=response.get('params', {}),
                   status=response['status'], frames=[], errors=normalized_errors, reason=reason)
    items = []
    for timestamp, _ in frames:
        frame_reason = errors_by_ts.get(timestamp)
        if frame_reason:
            status = 'failed'
        elif response['status'] == 'complete' or mapped_partial:
            status = 'complete'
        else:
            status = 'not_run' if response['status'] == 'not_run' else 'failed'
            frame_reason = reason
        attempt['frames'].append(_frame(timestamp, refs, status, frame_reason))
        frame_items = [row for row in rows if row['timestamp'] == timestamp]
        if status == 'complete':
            for row in frame_items or [dict(text='')]:
                items.append(_item(timestamp, refs, row['text'], 'rapidocr', model,
                                   native_reasons[timestamp], row))
    attempt['status'] = _status(attempt['frames'])
    return items, attempt


def recognize_auto(frames, refs, ocr_bin, runner=None, rapid=None) -> dict:
    """Run native once, then RapidOCR once for only the unsuccessful frames.

    ``frames`` contains (timestamp, image_bytes); ``refs`` maps timestamps to
    evidence IDs. ``runner`` injects the native subprocess runner and ``rapid``
    injects a callable(frames, refs). The default RapidOCR fallback has a bounded offline runner.
    Empty successful observations remain explicit items and attempt frames.
    Preserve attempts separately when downstream text merging drops metadata.
    """
    frames = list(frames)
    params = dict(strategy_version=STRATEGY_VERSION,
                  native_timeout_seconds=NATIVE_TIMEOUT_SECONDS,
                  fallback_timeout_seconds=FALLBACK_TIMEOUT_SECONDS,
                  fallback_on='native_error_only', automatic_download=False)
    if not frames:
        return dict(status='complete', backend='macos', model=NATIVE_MODEL,
                    params=params, items=[], errors=[], fallback_from=None,
                    reason=None, attempts=[])
    items, native = _native(frames, refs, ocr_bin, runner)
    attempts = [native]
    pending = [frame for frame, outcome in zip(frames, native['frames']) if outcome['status'] != 'complete']
    if pending:
        native_reasons = {frame['timestamp']: frame['reason'] for frame in native['frames']
                          if frame['status'] != 'complete'}
        fallback_items, fallback = _rapid(pending, refs, rapid, native_reasons)
        items.extend(fallback_items)
        attempts.append(fallback)
    completed_backends = {item['backend'] for item in items}
    backend = 'mixed' if len(completed_backends) > 1 else next(iter(completed_backends), attempts[-1]['backend'])
    model = ({attempt['backend']: attempt['model'] for attempt in attempts}
             if backend == 'mixed' else next(attempt['model'] for attempt in attempts if attempt['backend'] == backend))
    final_frames = [frame for frame in native['frames'] if frame['status'] == 'complete']
    final_frames.extend(attempts[-1]['frames'] if pending else [])
    status = _status(final_frames)
    # An executed native failure is still a failure if the fallback is absent.
    if status == 'not_run' and native['status'] != 'not_run':
        status = 'failed'
    reasons = [attempt['reason'] for attempt in attempts if attempt['reason']]
    reason = ('macos fallback: ' + '; '.join(reasons)) if pending else None
    order = {timestamp: index for index, (timestamp, _) in enumerate(frames)}
    items.sort(key=lambda item: order[item['timestamp']])
    return dict(status=status, backend=backend, model=model, params=params,
                items=items, errors=[error for attempt in attempts for error in attempt['errors']],
                fallback_from='macos' if pending else None, reason=reason, attempts=attempts)
